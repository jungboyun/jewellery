<?
	setcookie("cookie_no","");//쿠키삭제-no
	setcookie("cookie_name","");//쿠키삭제-name
	echo("<script>location.href='index.html'</script>");//페이지이동
?>
