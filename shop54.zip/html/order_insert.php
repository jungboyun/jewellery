<?
   include "common.php";
   $cookie_no=$_COOKIE[cookie_no];
   $o_no=$_REQUEST[o_no];
   $o_name=$_REQUEST[o_name];
   $o_tel=$_REQUEST[o_tel];
   $o_phone=$_REQUEST[o_phone];
   $o_email=$_REQUEST[o_email];
   $o_zip=$_REQUEST[o_zip];
   $o_juso=$_REQUEST[o_juso];
   $r_name=$_REQUEST[r_name];
   $r_tel=$_REQUEST[r_tel];
   $r_phone=$_REQUEST[r_phone];
   $r_email=$_REQUEST[r_email];
   $r_zip=$_REQUEST[r_zip];
   $r_juso=$_REQUEST[r_juso];
   $memo=$_REQUEST[memo];
   $cart=$_COOKIE[cart];
   $n_cart=$_COOKIE[n_cart];
   $pay_method=$_REQUEST[pay_method];
   $card_kind=$_REQUEST[card_kind];
   $card_halbu=$_REQUEST[card_halbu];   
   $bank_kind=$_REQUEST[bank_kind];
   $bank_sender=$_REQUEST[bank_sender];
   $product_nums=0;
   $product_names="";
   $total_cash=0;

   $query="select no54 from jumun where jumunday54=curdate() order by no54 desc";
   $result=mysqli_query($db,$query);
   $row=mysqli_fetch_array($result);
   $count=mysqli_num_rows($result);
   $jumun_no=$row[no54];
   $jumun_no=substr("$jumun_no",-4);
   
   if($count>0){
      $jumun_no=date("ymd").$jumun_no+1;
   }
   else{
      $jumun_no=date("ymd")."0001";
   }
   $jumunday=substr("$jumun_no",0,6);

   for($i=1;$i<=$n_cart;$i++){
         if($cart[$i]){
         list($no, $num, $opts1, $opts2)=explode("^", $cart[$i]);
         $query="select *from product where no54=$no";
         $result=mysqli_query($db,$query);
         $row=mysqli_fetch_array($result);
         $cash = round($row[price54]*(100-$row[discount54])/100,-3);
         $query="insert into jumuns (jumun_no54, product_no54, num54, price54, cash54, discount54, opts1_no54, opts2_no54)
                        values ('$jumun_no', $no, $num, $row[price54], $cash, $row[discount54], $opts1, $opts2);";
   
         $result=mysqli_query($db,$query);
         if (!$result) exit("에러: $query");
         
         setcookie("cart[$i]",null);

         $total_cash=$total_cash+($cash*$num);
         $product_nums=$product_nums+1;
         if($product_nums==1)$product_names=$row[name54];
      }
   }
   $n_cart = 0;
   setcookie("n_cart",$n_cart);

   if($product_nums>1){
      $tmp=$product_nums;
      $tmp=$tmp-1;
      $product_names=$product_names." 외 ".$tmp;
   }

   if($total_cash<$max_baesongbi){
      $query="insert into jumuns (jumun_no54, product_no54, num54, price54, cash54, discount54, opts1_no54, opts2_no54)
                        values ($jumun_no, 0, 1, $baesongbi, $baesongbi, 0, 0, 0);";
      $result=mysqli_query($db,$query);
      if (!$result) exit("에러: $query");
      $total_cash=$total_cash+$baesongbi;
   }

   if($cookie_no) $member_no=$cookie_no;
   else $member_no=0;

   $query="insert into jumun (no54, member_no54, jumunday54, product_names54, product_nums54, o_name54, o_tel54, o_phone54, o_email54, o_zip54, o_juso54, r_name54, r_tel54, r_phone54, r_email54, r_zip54, r_juso54, memo54, pay_method54, card_okno54, card_halbu54, card_kind54, bank_kind54, bank_sender54, total_cash54, state54)
                        values ('$jumun_no', $member_no, '$jumunday', '$product_names', $product_nums, '$o_name', '$o_tel', '$o_phone', '$o_email', '$o_zip', '$o_juso', '$r_name', '$r_tel', '$r_phone', '$r_email', '$r_zip', '$r_juso', '$memo', $pay_method, '123456789', $card_halbu, $card_kind, $bank_kind, '$bank_sender', $total_cash, 1);";
   
   $result=mysqli_query($db,$query);
   if (!$result) exit("에러: $query");

   echo("<script>location.href='order_ok.php'</script>");
?>