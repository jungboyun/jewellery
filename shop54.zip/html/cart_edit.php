	<?
	include "common.php";

   $no=$_REQUEST[no];
   $opts1=$_REQUEST[opts1];
   $opts2=$_REQUEST[opts2];
   $num=$_REQUEST[num];
   $num1=$_REQUEST[num];
   $pos=$_REQUEST[pos];
   $cart=$_COOKIE[cart];
   $n_cart=$_COOKIE[n_cart];
   $kind=$_REQUEST[kind];

   if(!$n_cart) $n_cart=0; //장바구니 제품개수($n_cart) 초기화
   switch($kind)
   {
      case "insert": //장바구니 담기
         $n_cart++;
         $cart[$n_cart]=implode("^",array($no, $num, $opts1, $opts2));
         setcookie("cart[$n_cart]",$cart[$n_cart]);		//setcookie (쿠키명, 쿠키값, 유효시간(초), 경로, 도메인, 보안, httponly);
         setcookie("n_cart",$n_cart);
         break;

      case "order": //바로 구매하기
         $n_cart++;
         $cart[$n_cart]=implode("^",array($no, $num, $opts1, $opts2));
         setcookie("cart[$n_cart]",$cart[$n_cart]);
         setcookie("n_cart",$n_cart);
         break;

      case "delete": //장바구니 삭제
         setcookie("cart[$pos]",null);
         break;

      case "update": //장바구니 수량 수정
         list($no, $num, $opts1, $opts2)=explode("^", $cart[$pos]);
         $cart[$pos]=implode("^",array($no, $num1, $opts1, $opts2));
         setcookie("cart[$pos]",$cart[$pos]);
         break;

      case "deleteall": //장바구니 전체 비우기
         for($i=1;$i<=$n_cart;$i++){
            if($cart[$i]) setcookie("cart[$i]",null);
         }

         $n_cart=0;
         setcookie("n_cart",$n_cart);
         break;
   }

   if($kind=="order"){
	   echo("<script>location.href='order.php'</script>");
	   }
	else{
	   echo("<script>location.href='cart.php'</script>");
	   }
?>