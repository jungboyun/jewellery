<?
	include "../common.php";

	$image1=$_REQUEST[image1];
	$image2=$_REQUEST[image2];
	$image3=$_REQUEST[image3];
	
	$fname1="image1";
	if ($_FILES["image1"]["error"]==0) 
	{
		$fname1=$_FILES["image1"]["name"];    
		if (!move_uploaded_file($_FILES["image1"]["tmp_name"],
			  "../product/" . $fname1)) exit("업로드 실패");
	}	

	$fname2="image2";
	if ($_FILES["image2"]["error"]==0) 
	{
		$fname2=$_FILES["image2"]["name"];    
		if (!move_uploaded_file($_FILES["image2"]["tmp_name"],
			  "../product/" . $fname2)) exit("업로드 실패");
	}	

	$fname3="image3";
	if ($_FILES["image3"]["error"]==0) 
	{
		$fname3=$_FILES["image3"]["name"];    
		if (!move_uploaded_file($_FILES["image3"]["tmp_name"],
			  "../product/" . $fname3)) exit("업로드 실패");
	}	
	
	$menu=$_REQUEST[menu];
	$code=$_REQUEST[code];	
	$name=$_REQUEST[name];
	$name=addslashes($name);
	$coname=$_REQUEST[coname];
	$price=$_REQUEST[price];
	$opt1=$_REQUEST[opt1];
	$opt2=$_REQUEST[opt2];
	$contents=$_REQUEST[contents];
	$contents=addslashes($contents);
	$status=$_REQUEST[status];
	$icon_new=$_REQUEST[icon_new];
	$icon_hit=$_REQUEST[icon_hit];
	$icon_sale=$_REQUEST[icon_sale];
	$icon=$_REQUEST[icon];
	$discount=$_REQUEST[discount];
	$regday1=$_REQUEST[regday1];
	$regday2=$_REQUEST[regday2];
	$regday3=$_REQUEST[regday3];
	$regday=sprintf("%04d-%02d-%02d",$regday1,$regday2,$regday3);

	if($icon_new==1) $icon_new=1; else $icon_new=0;
	if($icon_hit==1) $icon_hit=1; else $icon_hit=0;
	if($icon_sale==1) $icon_sale=1; else $icon_sale=0;

	$query="insert into product (menu54,code54,name54,coname54,price54,opt1,opt2,contents54,status54,icon_new54,icon_hit54,icon_sale54,discount54,regday54,image1,image2,image3) values('$menu','$code','$name','$coname','$price','$opt1','$opt2','$contents','$status','$icon_new','$icon_hit','$icon_sale','$discount','$regday','$fname1','$fname2','$fname3');";
	$result=mysqli_query($db,$query);
	if(!$result) exit("에러:$query");

	echo("<script>location.href='product.php?no=$row[no54]&sel1=$sel1&sel2=$sel2&sel3=$sel3&sel4=$sel4&text1=$text1&page=$page'</script>");
?>
