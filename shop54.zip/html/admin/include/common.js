function menu()
{
	var s_menu;

	s_menu="<table width='900' border='0' cellspacing='0' cellpadding='3'>" + "\n"
+ "		<tr><td height='45' align='center' bgcolor='#F7F7F7'>" + "\n"
+ "			<table width='900' border='0' cellspacing='0' cellpadding='0'>" + "\n"
+ "			<tr><td align='center'>" + "\n"
+ "            <table width='680' border='0' cellspacing='1' cellpadding='6' bgcolor='#CCCCCC'>" + "\n"
+ "              <tr> " + "\n"
+ "                <td align='center' bgcolor='#F2F2F2'> " + "\n"
+ "                    <table width='620' border='0' cellspacing='0' cellpadding='2'>" + "\n"
+ "                      <tr> " + "\n"
+ "                        <td width='100'><font color='#0457A2'>▶ <a href='member.php'>회원관리</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>▶ <a href='product.php'>상품관리</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>▶ <a href='jumun.php'>주문관리</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>▶ <a href='opt.php'>옵션관리</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>▶ <a href='faq.html'>FAQ관리</font></a></td>" + "\n"
+ "                      </tr>" + "\n"
+ "                    </table>" + "\n"
+ "                </td>" + "\n"
+ "              </tr>" + "\n"
+ "            </table>" + "\n"
+ "			</td></tr></table>" + "\n"
+ "		</td></tr>" + "\n"
+ "		</table>" + "\n"
+ "  <hr width='900' size='1'>" + "\n";

  return s_menu;
}

