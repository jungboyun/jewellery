<?
	include "../common.php";;

	$name=$_REQUEST[name];
	$no1=$_REQUEST[no1];

	$query="update opt set name54='$name' where no54=$no1;";
			
	$result=mysqli_query($db,$query);
	if(!$result) exit("에러:$query");

	echo("<script>location.href='opt.php'</script>");
?>
