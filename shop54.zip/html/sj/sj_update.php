<?
	include "common.php";
	
	$no=$_REQUEST[no];
	$name=$_REQUEST[name];
	$kor=$_REQUEST[kor];
	$eng=$_REQUEST[eng];
	$mat=$_REQUEST[mat];
	$hap=$_REQUEST[hap];
	$avg=$_REQUEST[avg];

	$query="update sj set name54='$name',kor54=$kor,eng54=$eng,mat54=$mat,
			hap54=$hap,avg54=$avg where no54=$no;";
	$result=mysqli_query($db,$query);
	if(!$result) exit("에러:$query");

	echo("<script>location.href='sj_list.php'</script>");
?>