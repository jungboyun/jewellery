<?
	$page_line=5;
	$page_block=5;
	
	$db=mysqli_connect("localhost","shop54","1234","shop54");
	if(!$db) exit("DB연결에러");
?>