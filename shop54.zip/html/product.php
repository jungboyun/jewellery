<!-------------------------------------------------------------------------------------------->	
<!-- 프로그램 : 쇼핑몰 따라하기 실습지시서 (실습용 HTML)                                    -->
<!--                                                                                        -->
<!-- 만 든 이 : 윤형태 (2008.2 - 2017.12)                                                    -->
<!-------------------------------------------------------------------------------------------->	

<?
	include "common.php";
	include "main_top.php";
	$menu=$_REQUEST[menu];
	$page=$_REQUEST[page];
	

	//$query = "select * from product where menu54=$menu and status54=1"; 

				$sort=$_REQUEST[sort];
				$price=$_REQUEST[price];
				$name=$_REQUEST[name];
				$no=$_REQUEST[no];
				$up=$_REQUEST[up];
				$down=$_REQUEST[down];
				$name=$_REQUEST[name];
				$status=$_REQUEST[status];
				

				if($sort=="up")
					$query = "select * from product where menu54=$menu and status54=1 order by price54 desc";
				elseif($sort=="down")
					$query = "select * from product where menu54=$menu and status54=1 order by price54";
				elseif($sort=="name")
					$query = "select * from product where menu54=$menu and status54=1 order by name54";
				else
					$query = "select * from product where menu54=$menu and status54=1 order by no54 desc";


	$result=mysqli_query($db,$query);
	if(!$result)exit("에러: $query");
	$count=mysqli_num_rows($result);
			
?>

<!-------------------------------------------------------------------------------------------->	
<!-- 시작 : 다른 웹페이지 삽입할 부분                                                       -->
<!-------------------------------------------------------------------------------------------->	


      <!-- 하위 상품목록 -->

			<!-- form2 시작 -->
			<form name="form2" method="post" action="product.php">
			<input type="hidden" name="menu" value="<?=$menu?>">

			<table border="0" cellpadding="0" cellspacing="5" width="767" class="cmfont" bgcolor="#efefef">
				<tr>
					<td bgcolor="white" align="center">
						<table border="0" cellpadding="0" cellspacing="0" width="751" class="cmfont">
							<tr>
								<td align="center" valign="middle">
									<table border="0" cellpadding="0" cellspacing="0" width="730" height="40" class="cmfont">
										<tr>
											<td width="500" class="cmfont">
												<font color="#C83762" class="cmfont"><b><?=$a_menu[$menu]?> &nbsp</b></font>&nbsp
											</td>
											<td align="right" width="274">
												<table width="100%" border="0" cellpadding="0" cellspacing="0" class="cmfont">
													<tr>
														<td align="right"><font color="EF3F25"><b><?=$count?></b></font> 개의 상품.&nbsp;&nbsp;&nbsp</td>
														<td width="100">
															<select name="sort" size="1" class="cmfont" onChange="form2.submit()">
																
																<?
																if($sort=="new")
																	echo("<option value='new' selected>신상품순 정렬</option>");
																else   
																	echo("<option value='new'>신상품순 정렬</option>");

																if($sort=="up")
																	   echo("<option value='up' selected>고가격순 정렬</option>");         
																else   
																		echo("<option value='up'>고가격순 정렬</option>");  

																if($sort=="down")
																	   echo("<option value='down' selected>저가격순 정렬</option>");
																else  
																		echo("<option value='down'>저가격순 정렬</option>");

																if($sort=="name")
																	  echo("<option value='name' selected>상품명 정렬</option>");
																else  
																		echo("<option value='name'>상품명 정렬</option>");                                        
																?>
															</select>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			</form>


			<!-- form2 -->

			
				<!--- 1 번째 줄 -->
	<?
	$num_col=5; 
	$num_row=4;
	$page_line=$num_col*$num_row;
	$icount=0;
	
	if(!$page) $page=1;
	$pages=ceil($count/$page_line);
	$first=1;
	if($count>0) $first=$page_line*($page-1);
	$page_last=$count-$first;
	if($page_last>$page_line) $page_last=$page_line;

	if($count>0) mysqli_data_seek($result,$first);

	for($i=0; $i<$page_last; $i++)
	{
			echo("<table border='0' cellpadding='0' cellspacing='0'>");
				
			for($ir=0; $ir<$num_row; $ir++)
			{	
				echo("<tr>");
				
				for($ic=0; $ic<$num_col; $ic++)
				{					
					if($icount < $count)
					{

						$row=mysqli_fetch_array($result);
						$saleprice=round($row[price54]*(100-$row[discount54])/100,-3);
						$number1=number_format($row[price54],0);
						$number2=number_format($saleprice);
						echo("
							<td width='150' height='205' align='center' valign='top'>
								<table border='0' cellpadding='0' cellspacing='0' width='100' class='cmfont'>
									<tr> 
										<td align='center'> 
											<a href='product_detail.php?no=$row[no54]'><img src='product/$row[image1]' width='120' height='140' border='0'></a>
										</td>
									</tr>
									<tr><td height='5'></td></tr>
									<tr> 
										<td height='20' align='center'>
											<a href='product_detail.php?no=$row[no54]'><font color='444444'>$row[name54]</font></a>&nbsp; 
							");			
											if($row[icon_new54]==1)
											echo("<img src='images/i_new.gif' align='absmiddle' vspace='1'>");
											if($row[icon_hit54]==1)
											echo("<img src='images/i_hit.gif' align='absmiddle' vspace='1'>");
											if($row[icon_sale54]==1)
											echo("<img src='images/i_sale.gif' align='absmiddle' vspace='1'>
												<font color='red'>$row[discount54]%</font></br>
												<strike>$number1 원</strike> 
												<tr><td height='20' align='center'><b>$number2 원</b></td></tr>
												");	
												
							echo("				
										</td>
									</tr>
								");
?>
									<?
									if($row[icon_sale54]==0)
									echo("
									<tr><td height='20' align='center'><b>$number1 원</b></td></tr>
									");
									?>
<?
							echo("	
								</table>
							</td>
							");
					}
					else
						echo("<td></td>");
					$icount++;
				}
				echo("</tr>
				<tr><td height='10'></td>
				</tr>");
			}		
	
	}			
			echo("</table>");
?>

<?
	$blocks=ceil($pages/$page_block);
	$block=ceil($page/$page_block);
	$page_s=$page_block*($block-1);
	$page_e=$page_block*$block;
	if($blocks<=$block) $page_e=$pages;

	echo("<table width='400' border='0'>
	
	<tr>
	<td height='20' align='right'>");

	if($block>1)
	{
		$tmp=$page_s;
		echo("<a href='product.php?page=$tmp&text1=$text1&menu=$menu&sort=$sort'>
				<img src='images/i_prev.gif' align='absmiddle' border='0'>
			</a>&nbsp");
	}

	for($i=$page_s+1; $i<=$page_e; $i++)
	{
		if($page==$i)
			echo("<font color='red'><b>$i</b></font>&nbsp");
		else
			echo("<a href='product.php?page=$i&text1=$text1&menu=$menu&sort=$sort'>[$i]</a>&nbsp");
	}

	if($block<$blocks)
	{
		$tmp=$page_e+1;
		echo("&nbsp<a href='product.php?page=$tmp&text1=$text1&menu=$menu&sort=$sort'>
			<img src='images/i_next.gif' align='absmiddle' border='0'>
		</a>");
	}
	echo(" </td>
	</tr>
	</table>");
?>

<!--
				<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="150" height="205" align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100" class="cmfont">
							<tr> 
								<td align="center"> 
									<a href="product_detail.html?no=109469"><img src="product/0000_s.jpg" width="120" height="140" border="0"></a>
								</td>
							</tr>
							<tr><td height="5"></td></tr>
							<tr> 
								<td height="20" align="center">
									<a href="product_detail.html?no=1"><font color="444444">메뉴1 상품</font></a>&nbsp; 
									<img src="images/i_hit.gif" align="absmiddle" vspace="1"> <img src="images/i_new.gif" align="absmiddle" vspace="1"> 
								</td>
							</tr>
							<tr><td height="20" align="center"><b>98,000 원</b></td></tr>
						</table>
					</td>
					<td width="150" height="205" align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100" class="cmfont">
							<tr> 
								<td align="center"> 
									<a href="product_detail.html?no=109469"><img src="product/0000_s.jpg" width="120" height="140" border="0"></a>
								</td>
							</tr>
							<tr><td height="5"></td></tr>
							<tr> 
								<td height="20" align="center">
									<a href="product_detail.html?no=109469"><font color="444444">메뉴1 상품</font></a>&nbsp; 
									<img src="images/i_hot.gif" align="absmiddle" vspace="1"> <img src="images/i_sale.gif" align="absmiddle" vspace="1"> <font color="red">20%</font>
								</td>
							</tr>
							<tr><td height="20" align="center"><strike>98,000 원</strike><br><b>70,000 원</b></td></tr>
						</table>
					</td>

					<td width="150" height="205" align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100" class="cmfont">
							<tr> 
								<td align="center"> 
									<a href="product_detail.html?no=109469"><img src="product/0000_s.jpg" width="120" height="140" border="0"></a>
								</td>
							</tr>
							<tr><td height="5"></td></tr>
							<tr> 
								<td height="20" align="center">
									<a href="product_detail.html?no=109469"><font color="444444">메뉴1 상품</font></a>&nbsp; 												
								</td>
							</tr>
							<tr><td height="20" align="center"><b>98,000 원</b></td></tr>
						</table>
					</td>

					<td width="150" height="205" align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100" class="cmfont">
							<tr> 
								<td align="center"> 
									<a href="product_detail.html?no=109469"><img src="product/0000_s.jpg" width="120" height="140" border="0"></a>
								</td>
							</tr>
							<tr><td height="5"></td></tr>
							<tr> 
								<td height="20" align="center">
									<a href="product_detail.html?no=109469"><font color="444444">메뉴1 상품</font></a>&nbsp; 												
								</td>
							</tr>
							<tr><td height="20" align="center"><b>98,000 원</b></td></tr>
						</table>
					</td>

					<td width="150" height="205" align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100" class="cmfont">
							<tr> 
								<td align="center"> 
									<a href="product_detail.html?no=109469"><img src="product/0000_s.jpg" width="120" height="140" border="0"></a>
								</td>
							</tr>
							<tr><td height="5"></td></tr>
							<tr> 
								<td height="20" align="center">
									<a href="product_detail.html?no=109469"><font color="444444">메뉴1 상품</font></a>&nbsp; 												
								</td>
							</tr>
							<tr><td height="20" align="center"><b>98,000 원</b></td></tr>
						</table>
					</td>

				</tr>
				<tr><td height="10"></td></tr>
				
				
			</table>
			
			<table border="0" cellpadding="0" cellspacing="0" width="690">
				<tr>
					<td height="40" class="cmfont" align="center">
						<img src="images/i_prev.gif" align="absmiddle" border="0"> 
						<font color="#FC0504"><b>1</b></font>&nbsp;
						<a href="product.html?menu=1&sort=1&page=1"><font color="#7C7A77">[2]</font></a>&nbsp;
						<a href="product.html?menu=1&sort=1&page=1"><font color="#7C7A77">[3]</font></a>&nbsp;
						<img src="images/i_next.gif" align="absmiddle" border="0">
					</td>
				</tr>
			</table>

			-->


<!-------------------------------------------------------------------------------------------->	
<!-- 끝 : 다른 웹페이지 삽입할 부분                                                         -->
<!-------------------------------------------------------------------------------------------->	

<?
	include "main_bottom.php";
?>
