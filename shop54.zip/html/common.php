<?
	$page_line=5;
	$page_block=5;
	
	$db=mysqli_connect("localhost","shop54","1234","shop54");
	if(!$db) exit("DB연결에러");

	$admin_id="admin";
	$admin_pw="1234";

	$a_idname=array("전체","이름","ID");
	$n_idname=count($a_idname);

	$a_menu=array("분류선택","신상품","베스트100","로퍼/플랫","힐아이템","슬링백/뮬","스니커즈","샌들","9900","게시판","이벤트");
	$n_menu=count($a_menu);

	$a_status=array("상품상태","판매중","판매중지","품절");
	$n_status=count($a_status);

	$a_icon=array("아이콘","New","Hit","Sale");
	$n_icon=count($a_icon);

	$a_text1=array("","제품이름","제품번호");
	$n_text1=count($a_text1);

	$baesongbi = 2500;
    $max_baesongbi = 100000;

	$a_state=array("전체","주문신청","주문확인","입금확인", "배송중", "주문완료", "주문취소");
	$n_state=count($a_state);

	$a_name=array("주문번호","고객명","상품명");
	$n_name=count($a_name);


?>