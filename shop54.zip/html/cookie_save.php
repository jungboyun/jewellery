<?
	$irum=$_REQUEST[irum];
	setcookie("cookie_value",$irum);
	echo("<script>location.href='cookie_view.php'</script>");
?>
