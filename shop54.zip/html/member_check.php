<?
	include "common.php"; 
?>
<?
$uid=$_REQUEST[uid];
$pwd=$_REQUEST[pwd];

$query="select no54,name54 from member where uid54='$uid' and pwd54='$pwd';";
$result=mysqli_query($db,$query);
if(!$result)exit("에러:$query");

$count=mysqli_num_rows($result);

if($count>0)
{
	$row=mysqli_fetch_array($result);
	setcookie("cookie_no",$row[no54]);
	setcookie("cookie_name",$row[name54]);
	echo("<script>location.href='index.html'</script>");
}
else
	echo("<script>location.href='member_login.php'</script>");
?>
